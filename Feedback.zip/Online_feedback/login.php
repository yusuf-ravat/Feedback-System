<?php 
extract($_POST);
if(isset($save))
{

	if($en=="" || $p=="")
	{
		$err="<font color='red'>fill all the fileds first</font>";	
	}
	else
	{
		$pass=md5($p);	
		$sql=mysqli_query($conn,"select * from user where enrollment='$en' and pass='$pass' and status='0'");
		$r=mysqli_num_rows($sql);

	if($r==true)
	{
		$_SESSION['user']=$en;
		header('location:user');
	}

	else
		{
		$err="<font color='red'>Invalid login details</font>";
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Student Login </title>
</head>
<body>
	

<div class="row">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">

<form method="post">
	<div class="row" style="margin-top:50px">
		<div class="col-sm-5"></div>
		<div class="col-sm-4"><h2>Student Login Form</h2></div>
	</div>
	
	<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><?php echo @$err;?></div>
	</div>
	
	
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
		Enter Your Enrollmet<input type="text" name="en" class="form-control" required maxlength="12"  placeholder="Enter Enrollment"/></div>
	</div>
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
		Enter Your Password <input type="password" name="p" class="form-control" required maxlength="10" placeholder="Enter Password"/></div>
	</div>
		
	<div class="row" >
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
		<!-- <a href="forgot_pass_student.php">Forgot Password</a> -->

	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-8">
		<input type="submit" value="Login" name="save" class="btn btn-info"/>
		</div>
	</div>
</form>	
</div>
</div>
</body>
</html>