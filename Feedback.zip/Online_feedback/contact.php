<?php 
include('dbconfig.php');
extract($_POST);
if(isset($save))
{

mysqli_query($conn,"insert into contact values('','$n','$id','$e','$m','$msg',now())");
	echo "<script>alert('Admin Connetct as soon as possiblae')</script>";


}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
</head>
<body>
    

        <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                
                <ol class="breadcrumb">
                    
                    </li>
                   
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
       <div class="row">
            <div class="col-md-6">
                <h3><font color="#0000">Contact us </font></h3>
                <form name="sentMessage" method="post" id="contactForm" >
                  <?php echo @$err; ?>
				    <div class="control-group form-group">
                        
						
						<div class="controls">
                            <label>Name</label>
                            <input type="text" class="form-control" name="n" required  placeholder="Enter name">
                            <!-- <p class="help-block"></p> -->
                        </div>
                        <div class="controls">
                            <label>Id</label>
                            <input type="text" class="form-control" name="id" required pattern="[0-9].{5,11}"  minlength="6" maxlength="12" title="Please enter valid id" placeholder="Ex-17616030..">
                            <!-- <p class="help-block"></p> -->
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Mobile Number</label>
                            <input type="text" class="form-control" name="m" required pattern="[0-9].{9}" maxlength="10" title="Mobile number must be 10 digit"  placeholder="Enter mobile number">
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Email Address</label>
                            <input type="email" class="form-control" name="e" required  placeholder="Enter Email">
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Message</label>
                            <textarea rows="10" name="msg" cols="100" class="form-control" id="message" required maxlength="999" style="resize:none" placeholder="Type your messsage..."></textarea>
                        </div>
                    </div>

                    <div id="success"></div>
                    <!-- For success/fail messages -->
                    <button type="submit" name="save" class="btn btn-info">Send Message</button>
					<h1></h1>
                </form>
            </div>
            
			<div class="col-md-4" style="margin-top:30px">
                <h3>Contact Details</h3>
                
                <p>
                  Ahwa Road, Rajendrapur, Ta- Waghai Dist - Dang, Gujarat, Waghai<br>Gujarat 394730<br>
                </p>

                <p><i class="fa fa-phone"></i> 
                    <abbr title="Phone">P</abbr>: (02631) 246 789
                </p>

                <p>
                    <i class="fa fa-envelope-o"></i> 
                    <abbr title="Email">E</abbr>: <a href="mailto:feedbackgpw616@gmail.com">feedbackgpw616@gmail.com</a>
                </p>
            
                <p>
                    <i class="fa fa-clock-o"></i> 
                    <abbr title="Hours">H</abbr>: Monday - Friday: 10:00 AM to 5:00 PM
                </p>

                <ul class="list-unstyled list-inline list-social-icons">
                    <li>
                        <a href="https://www.facebook.com/GPWaghai/"><i class="fa fa-facebook-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="https://mobile.twitter.com/gpwaghai"><i class="fa fa-twitter-square fa-2x"></i></a>
                    </li>
                    <li>
                        <a href="http://www.gpwg.cteguj.in/"><i class="fa fa-google-plus-square fa-2x"></i></a>
                    </li>
                </ul>
            </div>
        </div>

        </div>
        
            <!-- Contact Details Column -->
            
        <!-- /.row -->

        <!-- Contact Form -->
        <!-- In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
        <!-- /.row -->

    <br/><br/>
    
    </div>
    <!-- /.container -->
    </body>
</html>