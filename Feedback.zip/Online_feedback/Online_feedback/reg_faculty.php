<?php 
extract($_POST);
if(isset($save))
{
	
$q=mysqli_query($conn,"select * from faculty where f_id='$id'");
$r=mysqli_num_rows($q);	
if($r==true)
{
// $err="<font color='red'>Already Exists</font>";
echo "<script>alert('This user already exists')</script>";

}
else
{	
	$pass=md5($pass);
	mysqli_query($conn,"insert into faculty values('','$name','$id','$designation','$dep','$email','$pass','$mob',now(),'1')");

	
// $err="<font color='blue'><h3 align='center'>Registration successfull !!<h3></font>";
echo "<script>alert('Registration successfull Please Wait until the admin approves')</script>";

}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Faculty Registration</title>
</head>
<body>
	

		<div class="row">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
		<form method="post" enctype="multipart/form-data" name="registration">
		<table class="table table-bordered" style="margin-bottom:50px">
	<caption><font color="#0000"><h2 align="center">Faculty Registration</h2></font></caption>
	<Tr>
		<Td colspan="2"><?php echo @$err;?></Td>
	</Tr>
				
				<tr>
					<td>Enter Your Name</td>
					<Td><input  type="text"  name="name" class="form-control" placeholder="Name" required/></td>
				</tr>
				<tr>
					<td>Enter Your ID</td>
					<Td><input  type="text" name="id" class="form-control" placeholder="ID" required  pattern="[0-9]{06}" title="Please Enter valid Id" maxlength="6" /></td>
				</tr>

				<tr>
					<td>Enetr Your Designation</td>
					<Td><input type="text"  name="designation" class="form-control" placeholder="Designation" required/></td>
				</tr>
				<tr>
					<td>Enter Your email </td>
					<Td><input type="email"  name="email" class="form-control" placeholder="Email" required/></td>
				</tr>
				
				<tr>
					<td>Enter Your Password </td>
					<Td><input type="password" name="pass" class="form-control" placeholder="Minimum 8 and Maximum 10" required pattern=".{8,10}" title="Password must be minimum 8 and maximum 10"/></td>
				</tr>
				
				<tr>
					<td>Enter Your Mobile </td>
					<Td><input type="text" name="mob" class="form-control" placeholder="Mobile Number" required maxlength="10" pattern="[6789][0-9]{9}" title="Enter valide mobile number"/></td>
				</tr>
				
				<tr>
					<td>Select Department</td>
					<Td><select name="dep" class="form-control" required>
					<option disabled selected value>Select Department</option>
					<option>Computer</option>
					<option>Civil</option>
					<option>Mechanical</option>
					</select>
					</td>
				</tr>
				
					
					
<Td colspan="2" align="center">
<input type="submit" value="Save" class="btn btn-info" name="save"/>
<input type="reset" value="Reset" class="btn btn-info"/>
				
					</td>
				</tr>
			</table>
		</form>
		</div>
		<div class="col-sm-2"></div>
		</div>
	</body>
</html>