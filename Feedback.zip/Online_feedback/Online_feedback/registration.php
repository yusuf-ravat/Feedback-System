<?php 
extract($_POST);
if(isset($save))
{
//check user alereay exists or not
$sql=mysqli_query($conn,"select * from user where enrollment='$en'");

$r=mysqli_num_rows($sql);

if($r==true)
{
// $err= "<font color='red'><h3 align='center'>This user already exists</h3></font>";
echo "<script>alert('This user already exists')</script>";

}
else
{


//encrypt your password
$pass=md5($p);


$query="insert into user values('','$n','$en','$e','$pass','$mob','$dept','$sem',now(),'1')";
mysqli_query($conn,$query);



// $err="<font color='blue'><h3 align='center'>Registration successfull !!<h3></font>";
echo "<script>alert('Registration successfull Please Wait until the admin approves')</script>";

}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Student Registration</title>
</head>
<body>
	

<div class="row">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
		<form method="post" enctype="multipart/form-data" name="registration">
		<table class="table table-bordered" style="margin-bottom:50px">
	<caption><font color="#0000"><h2 align="center">Student Registration</h2></font></caption>
	<Tr>
		<Td colspan="2"><?php echo @$err;?></Td>
	</Tr>
				
				<tr>
					<td>Enter Your Name</td>
					<Td><input  type="text" name="n" id="n" class="form-control" maxlength="30" placeholder="Name" required/></td>
				</tr>
				<tr>
					<td>Enter Enrollment</td>
					<Td><input  type="text" name="en" id ="en" class="form-control" placeholder="Enrollment Number" required pattern="[0-9]{12}" title="Please valid Enrollment number" maxlength="12" /></td>
				</tr>
				<tr>
					<td>Enter Your email </td>
					<Td><input type="email" name="e" id='e'class="form-control" placeholder="Email" required/></td>
				</tr>
				
				<tr>
					<td>Enter Your Password </td>
					<Td><input type="password" name="p" id='p' class="form-control" placeholder="Minimum 8 and Maximum 10" required pattern=".{8,10}" maxlength="10" title="Password must be minimum 8 and maximum 10"/></td>
				</tr>
				<tr>
					<td>Enter Your Mobile </td>
					<Td><input type="text" name="mob" id='mob' class="form-control" placeholder="Mobile Number" required pattern="[6789][0-9]{9}" maxlength="10" title="Enter valide mobile number"/></td>
				</tr>
				
				<tr>
					<td>Select Department</td>
					<Td><select name="dept" id="dept" class="form-control" required>
					<option disabled selected value>Select Department</option>
					<option>Computer</option>
					<option>Civil</option>
					<option>Mechanical</option>
					</select>
					</td>
				</tr>
				
				<tr>
					<td>Select Your Semester</td>
					<Td><select name="sem" id='sem' class="form-control" required>
					<option disabled selected value>Select Semester</option>
					<option>1</option>
					<option>2</option>
					<option>3</option>
					<option>4</option>
					<option>5</option>
					<option>6</option>
					</select>
					</td>
				</tr>
					
<Td colspan="2" align="center">
<input type="submit" value="Save" class="btn btn-info" name="save"/>
<input type="reset" value="Reset" class="btn btn-info"/>
				
					</td>
				</tr>
			</table>
		</form>
		</div>
		<div class="col-sm-2"></div>
		</div>

</body>
</html>

