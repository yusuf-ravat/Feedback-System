<?php 
extract($_POST);
if(isset($save))
{

	if($np=="" || $cp=="" || $op=="")
	{
	$err="<font color='red'>fill all the fileds first</font>";	
	}
	else
	{
$op=md5($op);	

$sql=mysqli_query($conn,"select * from user where pass='$op'");
$r=mysqli_num_rows($sql);
if($r==true)
{

	if($np==$cp)
	{
	$np=md5($np);
	$sql=mysqli_query($conn,"update user set pass='$np' where enrollment='$user'");
	
	// $err="<font color='blue'>Password updated </font>";
	echo "<script>alert('Password updated successfully')</script>";
	}
	else
	{
	// $err="<font color='red'>New  password not matched with Confirm Password </font>";
	echo "<script>alert('New  password not matched with Confirm Password ')</script>";
	}
}

else
{

// $err="<font color='red'>Wrong Old Password </font>";
echo "<script>alert('Wrong Old Password')</script>";


}
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Update Password</title>
</head>
<body>
	

<h2 align="center">Update Password</h2>
<form method="post">
	
	<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><?php echo @$err;?></div>
	</div>
	
	
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
		Enter Your Old Password
		<input type="password" name="op" class="form-control" required placeholder="Enter old password"/></div>
	</div>
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
		Enter Your New Password
		<input type="password" name="np" class="form-control" required placeholder="Enter new password" pattern=".{8,10}" maxlength="10" title="Password must be minimum 8 and maximum 10"/></div>
	</div>
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
		Enter Your Confirm Password
		<input type="password" name="cp" class="form-control" required placeholder="Enter confirm password" pattern=".{8,10}" maxlength="10" title="Password must be minimum 8 and maximum 10"/></div>
	</div>
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
		
		
		<input type="submit" value="Update Password" name="save" class="btn btn-success"/>
		<input type="reset" class="btn btn-danger"/>
		</div>
	</div>
</form>	
</body>
</html>