<?php 
extract($_POST);
if(isset($update))
{

$query="update user set name='$n',email='$e',mobile='$mob',semester='$sem' where enrollment='".$_SESSION['user']."'";

//$query="insert into user values('','$n','$e','$pass','$mob','$hob','$imageName','$dob',now())";
mysqli_query($conn,$query);



// $err="<font color='blue'>Profie updated successfully !!</font>";
echo "<script>alert('Profie updated successfully')</script>";


}


//select old data
//check user alereay exists or not
$sql=mysqli_query($conn,"select * from user where enrollment='".$_SESSION['user']."'");
$res=mysqli_fetch_assoc($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Update Profile</title>
</head>
<body>
	

<h2 align="center">Update Your Profile</h2>

		<form method="post">
			<table class="table table-bordered">
	<Tr>
		<Td colspan="1"><?php echo @$err;?></Td>
	</Tr>
				
				<tr>
					<td>Enter Your name</td>
					<Td><input class="form-control" value="<?php echo $res['name'];?>"  type="text" name="n"/></td>
				</tr>
				<tr>
					<td>Enter Your Enrollment</td>
					<Td><input class="form-control" readonly="true" value="<?php echo $res['enrollment'];?>"  type="number" name="en"/></td>
				</tr>
				<tr>
					<td>Enter Your email </td>
					<Td><input class="form-control" type="email" value="<?php echo $res['email'];?>"  name="e"/></td>
				</tr>
				
				
				<tr>
					<td>Enter Your Mobile </td>
					<Td><input class="form-control" type="text" value="<?php echo $res['mobile'];?>"  name="mob"/></td>
				</tr>

				<tr>
					<td>Enter Your Department </td>
					<Td><input class="form-control" type="text" value="<?php echo $res['department'];?>"  name="dep" readonly/></td>
				</tr>

				<tr>
					<td>Select Your Semester</td>
					<Td><select name="sem" class="form-control" required>
					
					<option>1</option>
					<option>2</option>
					<option>3</option>
					<option>4</option>
					<option>5</option>
					<option>6</option>
					</select>
					</td>
				</tr>
					
<Td colspan="4" align="center">
<input type="submit" class="btn btn-success" value="Update My Profile" name="update"/>
<input type="reset" class="btn btn-danger" value="Reset"/>
				
					</td>
				</tr>
			</table>
		</form>
		</body>
</html>