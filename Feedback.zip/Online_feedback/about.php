
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
    

    <!-- Navigation -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header" align="center"><font color="#0000">Online Faculty Feedback System</font> </h1>
                
            </div>
       
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row"  style="margin-bottom:50px;margin-left:90px;" >
           
               <P>Student Feedback system for <b>Government Polytechnic, Waghai.</b> Here we have developed the faculty feedback system, 
               which is generally used in the college to rate the faculty based on the subject performance. <br>
Here we have three modules as administrator, faculty and student. The administrator is the one who creates the faculty and student account by adding all faculty and students' information. 
Admin also checks the<br> result once all students entered the feedback. The faculty can also check the feedback on specific subjects. 
Students are registration themselves and log in to the feedback management system and give feedback <br> for specific faculty and their subject.
</P> 
               
            </div>
        </div>
        <!-- /.row -->

        <!-- Footer -->
        </body>
</html>