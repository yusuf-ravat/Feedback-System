<?php
	extract($_POST);
	if(isset($save))
	{	
	
	mysqli_query($conn,"update faculty set Name='$n',designation='$desg',email='$email',department='$dept',mobile='$mob' where f_id='".$_SESSION['faculty_login']."'");	

// $err="<font color='green'>Faculty Details updated</font>";
echo "<script>alert('Profile updated successfully')</script>";

	}

$con=mysqli_query($conn,"select * from faculty where f_id='".$_SESSION['faculty_login']."'");

$res=mysqli_fetch_assoc($con);	
//print_r($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Update Profile</title>
</head>
<body>

<!--<h3 class="page-header">Update Profile</h3>
--><div class="col-lg-8" style="margin:15px;">
	<form method="post">
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label><?php echo @$err;?></label>
        </div>
   	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Name</label>
            	<input type="text" value="<?php echo @$res['Name'];?>" name="n" class="form-control" required>
        </div>
   	</div>

	   <div class="control-group form-group">
    	<div class="controls">
        	<label>ID</label>
            	<input type="text" value="<?php echo @$res['f_id'];?>" readonly="true" name="f_id" class="form-control" required>
        </div>
   	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Designation</label>
            	<input type="text" value="<?php echo @$res['designation'];?>" name="desg" class="form-control" required>
        </div>
   	</div>
 	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Email</label>
            	<input type="email" value="<?php echo @$res['email'];?>"  name="email"  class="form-control" required>
        </div>
    </div>

	<div class="control-group form-group">
    	<div class="controls">
        	<label>Password</label>
            	<input type="password" value="********"  name="pas"  class="form-control" required readonly>
        </div>
    </div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Department</label>
            	<input type="text" value="<?php echo @$res['department'];?>"  readonly='true' name="dept"  class="form-control" required/>
        </div>
    </div>
					
					
                  
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Mobile Number</label>
            	<input type="text" id="mob" value="<?php echo @$res['mobile'];?>" class="form-control" name="mob"  required maxlength="10" pattern="[6789][0-9]{9}" title="Enter valide mobile number" />
        </div>
  	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
            	<input type="submit" class="btn btn-success" name="save" value="Update  Profile"/>
        </div>
  	</div>
	</form>
</div>
</body>
</html>