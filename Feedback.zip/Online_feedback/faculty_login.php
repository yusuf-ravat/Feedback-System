<?php 
extract($_POST);
if(isset($save))
{

	if($f_id=="" || $p=="")
	{
	$err="<font color='red'>fill all the fileds first</font>";	
	}
	else
	{
		$pass=md5($p);
$sql=mysqli_query($conn,"select * from faculty where f_id='$f_id' and password='$pass' and status='0'");

$r=mysqli_num_rows($sql);

if($r==true)
{
$_SESSION['faculty_login']=$f_id;
header('location:faculty');
}

else
{

$err="<font color='red'>Invalid login details</font>";

}
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Faculty Login</title>
</head>
<body>
	

<div class="row">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">

<form method="post">
	<div class="row" style="margin-top:50px">
		<div class="col-sm-5"></div>
		<div class="col-sm-4"><h2>Faculty Login Form</h2></div>
	</div>
	
	<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><?php echo @$err;?></div>
	</div>
	
	
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
		Enter Your Id <input type="text" name="f_id" class="form-control" required maxlength="6" placeholder="Enter Id"/></div>
	</div>
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
		Enter Your Password<input type="password" name="p" class="form-control" require maxlength="10" placeholder="Enter password"/></div>
	</div>

	<div class="row" >
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
		<!-- <a href="">Forgot Password</a> -->

	<div class="row" style="margin-top:10px">
		<div class="col-sm-4"></div>
		<div class="col-sm-8">
		<input type="submit" value="Login" name="save" class="btn btn-info"/>
		
		</div>
	</div>
</form>	
</div>
</div>
</body>
</html>