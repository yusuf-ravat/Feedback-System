<form method="post">
<table class="table table-hover">
<tr>

<th> Select Faculty</th>
<td>
<select name="faculty" class="form-control">
	<?php
	$sql=mysqli_query($conn,"select * from faculty");
	while($r=mysqli_fetch_array($sql))
	{
	echo "<option value='".$r['f_id']."'>".$r['Name']."</option>";
	}
		 ?>
</select>
</td>
<td><input name="sub" type="submit" value="Check Average" class="btn btn-success"/></td>
</tr>
</table>
</form>
<hr style="border:1px solid #e2e2e2"/>


<?php
extract($_POST);
if(isset($sub))
{
//Count total Votes
$r=mysqli_query($conn,"select * from feedback where faculty_id='$faculty'");
$c=mysqli_num_rows($r);	
echo "<h4>Total Student Attempts : ".$c."</h4>";
echo "<h4>Faculty Id : ".$faculty."</h4>";


error_reporting(1);

 ?>
<div class="row" style="overflow-x:auto;">

<div class="col-sm-13">

<table class="table table-bordered" >

	<thead >
	
	<tr class="success">
		<th>Subject</th>
		<th>Teacher provided the course outline having weekly content plan with list of  required text book</th>
		<th>Course objectives,learning outcomes and grading criteria are clear to me</th>
		<th>Course integrates throretical course concepts with the real world examples</th>
		<th>Teacher is punctual,arrives on time and leaves on time</th>
		<th>Teacher is good at stimulating the interest in the course content</th>
		<th>Teacher is good at explaining the subject matter</th>
		<th>Teacher's presentation was clear,loud ad easy to understand</th>
		<th>Teacher is good at using innovative teaching methods/ways</th>
		<th>Teacher is available and helpful during counseling hours</th>
		<th>Teacher has competed the whole course as per course outline</th>
		<th>Teacher was always fair and impartial</th>
		<th>Assessments conducted are clearly connected to maximize learining objectives</th>
		<th>Total</th>
		<th>Percentage</th>

		</tr>
		</thead>
		<?php
$q=mysqli_query($conn,"select * from feedback where faculty_id='$faculty'");
while($res=mysqli_fetch_array($q))
{	
	$sum=$res[6]+$res[7]+$res[8]+$res[9]+$res[10]+$res[11]+$res[12]+$res[13]+$res[14]+$res[15]+$res[16]+$res[17];
	$per=$sum/60*100;
	$avg=round($per);
	echo "<td>".$res[3]."</td>";
	echo "<td>".$res[6]."</td>";
	echo "<td>".$res[7]."</td>";
	echo "<td>".$res[8]."</td>";
	echo "<td>".$res[9]."</td>";
	echo "<td>".$res[10]."</td>";
	echo "<td>".$res[11]."</td>";
	echo "<td>".$res[12]."</td>";
	echo "<td>".$res[13]."</td>";
	echo "<td>".$res[14]."</td>";
	echo "<td>".$res[15]."</td>";
	echo "<td>".$res[16]."</td>";
	echo "<td>".$res[17]."</td>";
	echo "<td>".$sum."</td>";
	echo "<td>".$avg."%</td>";
	
	echo "<tr>";
}
echo $count;
}
?>