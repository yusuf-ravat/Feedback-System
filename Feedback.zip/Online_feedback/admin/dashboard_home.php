<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Home</title>
</head>
<body>
<h1 align="center" style="text-decoration:underline"><a href="">Admin Dashboard</a></h1><br>
<?php 
//all complaints
?>
<div class="row" style="overflow-x:auto;">

<div class="col-sm-13">

<table class="table table-bordered" >

	<thead >
	
	<tr class="success">
		<th>Total Number of Faculty </th>
		<th>Total Number of Student</th>
		<th>Total Number feedback given by users</th>
		</tr>
		</thead>
		<?php
$qq=mysqli_query($conn,"select * from faculty ");
$rows=mysqli_num_rows($qq);		
echo "<td>".$rows."</td>";		

//all emegency compalints
$q=mysqli_query($conn,"select * from user");
$r1=mysqli_num_rows($q);			
echo "<td>".$r1."</td>";


//all users
$q2=mysqli_query($conn,"select * from feedback");
$r2=mysqli_num_rows($q2);			
echo "<td>".$r2."</td>";	

?>
</body>
</html>

