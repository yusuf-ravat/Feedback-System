<?php
error_reporting(1);
	include('../dbconfig.php');
	extract($_POST);
	if(isset($save))
	{	
		if(strlen($mob)<10 || strlen($mob)>10)
		{
		$err="<font color='red'>Mobile number must be 10 digit</font>";
		}
		else
		{
		//for auto genrate Password
		/*
		$x=rand(1,99);
		$p= md5($x);
		$pass=substr($p,1,6);
		*/
		//for user_alias
		$temp=substr($name,0,4);
		$temp1=substr($mob,0,4);
		$user_name=$temp.$temp1;
		
$q=mysqli_query($conn,"select * from faculty where email='$email' and f_id='$id'");
	$r=mysqli_num_rows($q);	
	if($r)
	{
	$err="<font color='red'>This email already exists choose diff email.</font>";
	}
	else
	{	
		mysqli_query($conn,"insert into faculty values('','$user_name','$name','$id','$department','$dep','$email','$pass','$mob',now(),'0')");
		

		
	$err="<font color='blue'><h3 align='center'>Registration successfull !!<h3></font>";
	}
	}
}	

?>


<h1 class="page-header">Add Faculty</h1>
<div class="col-lg-8" style="margin:15px;">
	<form method="post">
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label><?php echo @$err;?></label>
        </div>
   	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Name</label>
            	<input type="text" value="<?php echo @$name;?>" name="name" class="form-control" required placeholder="Faculty Name">
        </div>
   	</div>

	   <div class="control-group form-group">
    	<div class="controls">
        	<label>ID</label>
            	<input type="number" value="<?php echo @$Id;?>" name="id" class="form-control" required placeholder="Faculty ID">
        </div>
   	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Designation</label>
            	<input type="text" value="<?php echo @$Designation;?>" name="designation" class="form-control" required placeholder="Faculty Designation">
        </div>
   	</div>
 	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Email</label>
            	<input type="email" value="<?php echo @$email;?>"  name="email" class="form-control" required placeholder="Faculty Email">
        </div>
    </div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Password</label>
            	<input type="password" value="<?php echo @$pass;?>"  name="pass" class="form-control" required placeholder="Faculty Password">
        </div>
    </div>
	
	<!-- <tr>
					<label> Department</label>
					<Td><select name="dep" class="form-control" required>

					<option>Computer</option>
					<option>Civil</option>
					<option>Mechanical</option>
					</select>
					</td>
				</tr> -->
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Department</label>
  <select name="dep" class="form-control" required>
					
					<option>Computer</option>
					<option>Civil</option>
					<option>Mechanical</option>
					</select>
					
        </div>
    </div>
                  
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Mobile Number</label>
            	<input type="number" id="mob" value="<?php echo @$mob;?>" class="form-control" maxlength="10" name="mob"  required placeholder="Faculty Mobile Number">
        </div>
  	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
            	<input type="submit" class="btn btn-success" name="save" value="Add New Faculty">
        </div>
  	</div>
	</form>


</div>